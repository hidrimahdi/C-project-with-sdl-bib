#ifndef BACKGROUND_H_INCLUDED
#define BACKGROUND_H_INCLUDED
typedef struct {
SDL_Rect camera,camera2;//x,y,h,w
SDL_Surface *imagebg;
Mix_Music *musique;
}Background;
void initBack(Background * b);
void afficherBack(Background b, SDL_Surface * screen,int partage);
void scrolling (SDL_Rect * b, int direction ,int wigth);
void QuitBack(Background * b);

#endif // BACKGROUND_H_INCLUDED
