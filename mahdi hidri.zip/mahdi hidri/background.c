#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <time.h>  
#include "background.h" 
void initBack(Background * b){
b->camera.x=0;
b->camera.y=0;
b->camera.w=1200;
b->camera.h=672;
b->camera2.x=0;
b->camera2.y=0;
b->camera2.w=600;
b->camera2.h=672;//(*b).   b->
Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
b->imagebg=IMG_Load("image/background.png");
b->musique = Mix_LoadMUS("music/background.mp3");
Mix_PlayMusic(b->musique, -1);
}
void afficherBack(Background b, SDL_Surface * screen,int partage){
SDL_BlitSurface(b.imagebg,&b.camera,screen,NULL);
if(partage){
SDL_Rect pos;
pos.x=600;
pos.y=0;
SDL_BlitSurface(b.imagebg,&b.camera2,screen,&pos);
}
}
void scrolling (SDL_Rect * b, int direction,int wigth){
int save=b->x;
b->x+=direction;//direction peut prendre comme valeurs 10 ou -10 ou 5 ou -5 ou 0(le (-) sign la directon et la valeur sign vitesse de deplacement
if(b->x<0 ||b->x>wigth-1200){
b->x=save;
}
}
void QuitBack(Background * b){
SDL_FreeSurface(b->imagebg);
Mix_FreeMusic(b->musique);
Mix_CloseAudio();
}
