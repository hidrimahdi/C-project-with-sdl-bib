#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

#include "background.h"
int main(int argc,char **argv){
SDL_Init(SDL_INIT_EVERYTHING);
SDL_Surface *screen=SDL_SetVideoMode(1200,672,32,SDL_HWSURFACE);
int continuer=1,partage=0,pas=5,pas2=5,direction=0,direction2=0;
Background b;
SDL_Event event;
initBack(&b);
while(continuer){
while(SDL_PollEvent(&event)){
switch (event.type){
	case SDL_QUIT:
	continuer=0;
	break;
	case SDL_KEYDOWN :
	switch (event.key.keysym.sym) {
	case SDLK_ESCAPE:
		continuer=0;
		break;
	case SDLK_p:
	partage=!partage;
	case SDLK_LEFT:
		direction=-1;
		break;
	case SDLK_RIGHT:
		direction=1;
		break;
	case SDLK_LSHIFT:
	case SDLK_RSHIFT:
		pas=10;
	}if(partage){
switch (event.key.keysym.sym) {
	case SDLK_q:
		direction2=-1;
		break;
	case SDLK_d:
		direction2=1;
		break;
	case SDLK_SPACE:
		pas2=10;
	}
}
	break;
	case SDL_KEYUP :
	switch (event.key.keysym.sym) {
	case SDLK_LEFT:
		if(direction==-1)direction=0;
		break;
	case SDLK_RIGHT:
		if(direction==1)direction=0;
		break;
	case SDLK_LSHIFT:
	case SDLK_RSHIFT:
		pas=5;
	}
	if(partage){
	
	switch (event.key.keysym.sym) {
	case SDLK_q:
		if(direction2==-1)direction2=0;
		break;
	case SDLK_d:
		if(direction2==1)direction2=0;
		break;
	case SDLK_SPACE:
		pas2=5;
	}		
	}
	break;
	}}
	if(partage){scrolling (&b.camera2,direction2*pas2,b.imagebg->w);}
	scrolling (&b.camera,direction*pas ,b.imagebg->w);
	afficherBack(b,screen,partage);
	SDL_Flip(screen);
	SDL_Delay(40);
}
QuitBack(&b);
SDL_FreeSurface (screen);
SDL_Quit;
}
