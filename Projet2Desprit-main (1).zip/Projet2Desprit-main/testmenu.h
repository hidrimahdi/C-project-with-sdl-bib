#ifndef MENU_H_
#define MENU_H_
#include "var.h"
int menu(SDL_Surface *screen, int *sound, int *fullscreen); //menu initial
#endif
