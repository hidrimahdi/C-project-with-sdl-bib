#ifndef menu_H_INCLUDED
#define menu_H_INCLUDED


#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <stdbool.h>
#include <math.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>


typedef struct {
SDL_Surface *crow ;
SDL_Rect crow_pos; 
SDL_Rect animation[8];
int frame; 
int show;
}curseur ;

void init_tab_anim(SDL_Rect* clip); 
void initialiser (curseur *p, int xmouse, int ymouse) ;
void afficher_curseur(curseur  * p , SDL_Surface *screen);
void animation(curseur  *p);
void mvt_curseur_x(curseur *p, int xmouse);
void mvt_curseur_y(curseur *p, int ymouse);

int afficher_menu(SDL_Surface *screen);







  #endif //	INCLUDED
